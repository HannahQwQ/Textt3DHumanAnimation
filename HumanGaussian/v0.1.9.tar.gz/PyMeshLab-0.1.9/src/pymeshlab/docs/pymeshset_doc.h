/****************************************************************************
* PyMeshLab                                                         o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005-2021                                           \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#ifndef PYMESHLAB_PYMESHSET_DOC_H
#define PYMESHLAB_PYMESHSET_DOC_H

namespace pymeshlab {
namespace doc {

//MeshSet::__init__
const char* PYMS_INIT_VERB =
		"Initializes a MeshSet, setting the verbosity with the given value "
		"(default is ``False``).";

//MeshSet::set_verbosity
const char* PYMS_SET_VERBOSITY_DOC =
		"Sets the verbosity when using the MeshSet class. When set to true, all"
		" the logs that usually are printed in the bottom left of MeshLab, "
		"will be printed when filters are applied.";

//MeshSet::number_meshes
const char* PYMS_NUMBER_MESHES_DOC =
		"Returns the number of meshes contained in the MeshSet.";

//MeshSet::number_rasters
const char* PYMS_NUMBER_RASTERS_DOC =
		"Returns the number of rasters contained in the MeshSet.";

//MeshSet::set_current_mesh
const char* PYMS_SET_CURRENT_MESH =
		"Selects as current mesh the mesh having the given ID. Raises a "
		":py:exc:`PyMeshLabException` if the given ID is not found in the MeshSet.";

//MeshSet::current_mesh
const char* PYMS_CURRENT_MESH =
		"Returns the current selected mesh of the MeshSet. Raises a "
		":py:exc:`PyMeshLabException` if the MeshSet has no selected mesh.";

//MeshSet::current_mesh_id
const char* PYMS_CURRENT_MESH_ID =
		"Returns the id of the current selected mesh of the MeshSet. Raises a "
		":py:exc:`PyMeshLabException` if the MeshSet has no selected mesh.";

//MeshSet::mesh_id_exists
const char* PYMS_MESH_ID_EXISTS =
		"Returns true if the given id exists in the MeshSet.";

//MeshSet::mesh
const char* PYMS_MESH =
		"Returns a reference to the mesh having the given id in the MeshSet. "
		"Raises a :py:exc:`PyMeshLabException` if the given ID is not found in "
		" the MeshSet.";

//MeshSet::load_new_mesh
const char* PYMS_LOAD_NEW_MESH =
		"Loads the mesh in the given filename and adds the mesh in the MeshSet. "
		"The loaded mesh becomes the current selected one. "
		"Raises a :py:exc:`PyMeshLabException` if the file is not found, if the "
		"format of the file is not known by PyMeshLab or if there was an error "
		"while loading the file.";

//MeshSet::load_current_mesh
const char* PYMS_LOAD_CURRENT_MESH =
		"Loads the mesh in the given filename and overwrites the current "
		"selected mesh. The loaded mesh remains the current selected one. "
		"Raises a :py:exc:`PyMeshLabException` if the file is not found, if the "
		"format of the file is not known by PyMeshLab or if there was an error "
		"while loading the file.";

//MeshSet::save_current_mesh
const char* PYMS_SAVE_CURRENT_MESH =
		"Saves the current selected mesh in the MeshSet in a file having the "
		"given file name. Raises a :py:exc:`PyMeshLabException` if the MeshSet "
		"has no current selected mesh, if the format of the file is not known "
		"by PyMeshLab or if there was an error while writing the file.";

//MeshSet::load_new_raster
const char* PYMS_LOAD_NEW_RASTER =
		"Loads the raster in the given filename and adds the raster in the MeshSet. "
		"The loaded raster becomes the current selected one. "
		"Raises a :py:exc:`PyMeshLabException` if the file is not found, if the "
		"format of the file is not known by PyMeshLab or if there was an error "
		"while loading the file.";

//MeshSet::save_mesh
const char* PYMS_ADD_MESH =
		"Adds a **copy** of the given mesh in the current MeshSet, with the given "
		"name. By default, the added mesh will be set as the current mesh. "
		"This behaviour can be changed by setting the arg ``set_as_current`` to "
		"``False``.";

//MeshSet::clear
const char* PYMS_CLEAR = 
		"Clears the meshset, deleting all its content.";

//MeshSet::load_project
const char* PYMS_LOAD_PROJECT =
		"Loads a project from the given file name and stores it in the MeshSet.";

//MeshSet::save_project
const char* PYMS_SAVE_PROJECT =
		"Saves the content of the MeshSet in a file having the given file name.";

//MeshSet::apply_filter
const char* PYMS_APPLY_FILTER =
		"Applies the filter having the given filter name in the MeshSet. "
		"Updates the current filter script, pushing the applied filter with the "
		"given parameters. "
		"Returns a dictionary containing pairs of [string - value] returned by "
		"the applied filter. "
		"See the :ref:`filter_list` page to a list of all the possible filters "
		"that can be applied using this function.";

//MeshSet::load_filter_script
const char* PYMS_LOAD_FILTER_SCRIPT =
		"Loads from a .mlx file the current filter script.";

//MeshSet::save_filter_script
const char* PYMS_SAVE_FILTER_SCRIPT =
		"Saves in a .mlx file the current filter script.";

//MeshSet::clear_filter_script
const char* PYMS_CLEAR_FILTER_SCRIPT =
		"Clears the current filter script.";

//MeshSet::apply_filter_script
const char* PYMS_APPLY_FILTER_SCRIPT =
		"Applies all the filters currently present in the filter script.";

//MeshSet::print_status
const char* PYMS_PRINT_STATUS =
		"Prints the status of the MeshSet (number of meshes, and for every mesh "
		"its ID, its label and its full name.)";

//MeshSet::filter_parameter_values
const char* PYMS_FILTER_PARAMETER_VALUES =
		"Returns a dictionary containing the parameters and their values "
		"that would be used by the given filter if the 'apply_filter' function "
		"is called in the current MeshSet. "
		"This function is useful to check which default values are set with the "
		"current status of the MeshSet. "
		"It takes also a (possibly empty) dictionary of parameters that could be "
		"set by the user: in this case, the output value of these parameters "
		"should be the same as input.";

//MeshSet::print_filter_list
const char* PYMS_PRINT_FILTER_LIST =
		"Prints the list of all the filters that can be applied in the MeshSet.";

//MeshSet::print_filter_parameter_list
const char* PYMS_PRINT_FILTER_PARAMETER_LIST =
		"Prints the list of the parameters of the given filter, with their "
		"default values.";

//MeshSet::print_current_filter_script
const char* PYMS_PRINT_FILTER_SCIRPT =
		"Prints all the filters present on the current filter script, with all "
		"the parameters and their values.";
}
}

#endif // PYMESHLAB_PYMESHSET_DOC_H
